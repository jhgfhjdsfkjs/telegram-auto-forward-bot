
# Rename this file to config.py and fill with your actual credentials

API_ID = 1234567
API_HASH = 'your_api_hash_here'
BOT_TOKEN = 'your_bot_token_here'

SOURCE_CHANNELS = [
    -1001111111111,  # Channel A
    -1002222222222   # Channel B
]

TARGET_CHANNEL = -1003333333333  # Destination channel
LOG_CHANNEL = -1004444444444     # Log channel

BUTTONS = [
    ["🌐 Visit Our Channel", "https://t.me/YourChannel"],
    ["🤖 Try This Bot", "https://t.me/YourBotUsername"]
]
